for num in range(1, 101):
    if num % 3 == 0 and num % 5 == 0:
        print("FizzFuzz")
    elif num % 3 == 0:
        print("Fizz")
    elif num % 5 == 0:
        print("Fuzz")
    else:
        print(num)

